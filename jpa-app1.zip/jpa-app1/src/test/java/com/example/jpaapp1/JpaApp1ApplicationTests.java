package com.example.jpaapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
