package com.example.microServicesapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
