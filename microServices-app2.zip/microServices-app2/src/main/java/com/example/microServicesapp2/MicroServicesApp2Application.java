package com.example.microServicesapp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicesApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicesApp2Application.class, args);
	}

}
