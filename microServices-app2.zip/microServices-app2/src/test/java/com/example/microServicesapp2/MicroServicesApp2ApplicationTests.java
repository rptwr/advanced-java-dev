package com.example.microServicesapp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
