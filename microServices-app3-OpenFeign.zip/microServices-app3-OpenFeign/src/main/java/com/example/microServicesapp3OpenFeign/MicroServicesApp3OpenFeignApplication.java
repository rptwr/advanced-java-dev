package com.example.microServicesapp3OpenFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicesApp3OpenFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicesApp3OpenFeignApplication.class, args);
	}

}
