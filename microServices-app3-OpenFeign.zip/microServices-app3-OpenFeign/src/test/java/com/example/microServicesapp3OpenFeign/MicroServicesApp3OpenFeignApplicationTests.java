package com.example.microServicesapp3OpenFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesApp3OpenFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
