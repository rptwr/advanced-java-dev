package com.example.microServicesapp4server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServicesApp4ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicesApp4ServerApplication.class, args);
	}

}
