package com.in28minutes.springapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringApp1Application.class, args);
	}

}
