package com.in28minutes.springapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
