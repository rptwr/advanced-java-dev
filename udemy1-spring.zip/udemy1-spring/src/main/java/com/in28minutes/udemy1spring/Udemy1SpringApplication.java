package com.in28minutes.udemy1spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Udemy1SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Udemy1SpringApplication.class, args);
	}

}
