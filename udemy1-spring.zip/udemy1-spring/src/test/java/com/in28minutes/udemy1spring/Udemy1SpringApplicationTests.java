package com.in28minutes.udemy1spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Udemy1SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
