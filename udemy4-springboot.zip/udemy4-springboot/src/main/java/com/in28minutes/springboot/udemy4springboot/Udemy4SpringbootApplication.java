package com.in28minutes.springboot.udemy4springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Udemy4SpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Udemy4SpringbootApplication.class, args);
	}

}
