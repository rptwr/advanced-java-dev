package com.in28minutes.springboot.udemy4springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Udemy4SpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
