package com.example.webServicesapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp1Application.class, args);
	}

}
