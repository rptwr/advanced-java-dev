package com.example.webServicesapp10mailapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp10MailApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
