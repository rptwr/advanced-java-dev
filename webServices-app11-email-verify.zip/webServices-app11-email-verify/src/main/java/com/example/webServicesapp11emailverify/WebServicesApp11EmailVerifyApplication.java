package com.example.webServicesapp11emailverify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp11EmailVerifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp11EmailVerifyApplication.class, args);
	}

}
