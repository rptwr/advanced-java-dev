package com.example.webServicesapp11emailverify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp11EmailVerifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
