package com.example.webServicesapp2returntype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp2ReturnTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp2ReturnTypeApplication.class, args);
	}

}
