package com.example.webServicesapp2returntype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp2ReturnTypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
