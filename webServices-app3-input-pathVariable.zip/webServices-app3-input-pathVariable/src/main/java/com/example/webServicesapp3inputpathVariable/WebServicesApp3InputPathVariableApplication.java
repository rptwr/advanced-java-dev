package com.example.webServicesapp3inputpathVariable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp3InputPathVariableApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp3InputPathVariableApplication.class, args);
	}

}
