package com.example.webServicesapp3inputpathVariable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp3InputPathVariableApplicationTests {

	@Test
	void contextLoads() {
	}

}
