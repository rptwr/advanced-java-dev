package com.example.webServicesapp4requestBody;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp4RequestBodyApplicationTests {

	@Test
	void contextLoads() {
	}

}
