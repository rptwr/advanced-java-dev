package com.example.webServicesapp5requestParam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp5RequestParamApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp5RequestParamApplication.class, args);
	}

}
