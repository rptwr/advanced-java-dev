package com.example.webServicesapp5requestParam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp5RequestParamApplicationTests {

	@Test
	void contextLoads() {
	}

}
