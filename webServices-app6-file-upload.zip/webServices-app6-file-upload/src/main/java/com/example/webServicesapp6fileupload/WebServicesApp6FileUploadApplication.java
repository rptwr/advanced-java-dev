package com.example.webServicesapp6fileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp6FileUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp6FileUploadApplication.class, args);
	}

}
