package com.example.webServicesapp6fileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp6FileUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
