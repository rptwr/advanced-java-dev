package com.example.webServicesapp7fileuploadjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp7FileUploadJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp7FileUploadJpaApplication.class, args);
	}

}
