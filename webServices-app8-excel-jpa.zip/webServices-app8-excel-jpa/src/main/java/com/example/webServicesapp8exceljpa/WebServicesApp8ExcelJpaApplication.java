package com.example.webServicesapp8exceljpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebServicesApp8ExcelJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebServicesApp8ExcelJpaApplication.class, args);
	}

}
