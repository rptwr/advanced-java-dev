package com.example.webServicesapp8exceljpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp8ExcelJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
