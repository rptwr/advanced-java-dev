package com.example.webServicesapp9responseentity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServicesApp9ResponseEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
